import { useState, useEffect } from 'react';
import Navigation from './components/Navigation';
import LandingPage from './components/LandingPage';
import LoginPage from './pages/LoginPage';
import SignUpPage from './pages/SignUpPage';
import DashboardPage from './pages/DashboardPage';
import DriverDashboardPage from './pages/DriverDashboardPage';
import CDLUploadPage from './pages/CDLUploadPage';
import LoadVerificationPage from './pages/LoadVerificationPage';
import LoadVerificationFlowPage from './pages/LoadVerificationFlowPage';
import ManageLoadsPage from './pages/ManageLoadsPage';
import ProtectedRoute from './components/ProtectedRoute';

export default function Router() {
  const [currentPath, setCurrentPath] = useState(window.location.pathname);
  const [forceUpdate, setForceUpdate] = useState(0);

  useEffect(() => {
    const handlePopState = () => {
      setCurrentPath(window.location.pathname);
      setForceUpdate((prev) => prev + 1);
    };

    window.addEventListener('popstate', handlePopState);
    return () => window.removeEventListener('popstate', handlePopState);
  }, []);

  if (currentPath === '/login') {
    return <LoginPage key={`login-${forceUpdate}`} />;
  }

  if (currentPath === '/signup') {
    return <SignUpPage key={`signup-${forceUpdate}`} />;
  }

  if (currentPath === '/dashboard') {
    return (
      <ProtectedRoute>
        <DashboardPage key={`dashboard-${forceUpdate}`} />
      </ProtectedRoute>
    );
  }

  if (currentPath === '/onboarding/cdl') {
    return (
      <ProtectedRoute>
        <CDLUploadPage key={`cdl-${forceUpdate}`} />
      </ProtectedRoute>
    );
  }

  if (currentPath === '/loads/verify') {
    return (
      <ProtectedRoute>
        <LoadVerificationPage key={`verify-${forceUpdate}`} />
      </ProtectedRoute>
    );
  }

  if (currentPath === '/loads/manage') {
    return (
      <ProtectedRoute>
        <ManageLoadsPage key={`manage-${forceUpdate}`} />
      </ProtectedRoute>
    );
  }

  if (currentPath === '/driver/dashboard') {
    return (
      <>
        <Navigation />
        <ProtectedRoute>
          <DriverDashboardPage key={`driver-dashboard-${forceUpdate}`} />
        </ProtectedRoute>
      </>
    );
  }

  if (currentPath.startsWith('/loads/verify/')) {
    return (
      <ProtectedRoute>
        <LoadVerificationFlowPage key={`verify-flow-${forceUpdate}`} />
      </ProtectedRoute>
    );
  }

  return (
    <>
      <Navigation />
      <LandingPage />
    </>
  );
}
